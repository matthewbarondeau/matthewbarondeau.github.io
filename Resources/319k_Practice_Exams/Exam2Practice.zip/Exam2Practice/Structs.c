// Exam2Practice
// Runs on LM4F120/TM4C123
// Mohit Tiwari and Matthew Barondeau
// Last Modified: 3/25/2018

#include "Constants.h"
#include "Pointers.h"
#include <stdint.h>

//Copy of MealyFSM so you can see what it looks like
/*
struct state {
    uint8_t output[4];
    uint8_t nextState[8];
};
typedef struct state state_t;

	state_t Mealy[8] ={
        {{0, 1, 0, 1}, {0, 0, 0 ,0, 1, 1, 1, 1}},
        {{1, 1, 1, 1}, {1, 1, 1 ,1, 2, 2, 2, 2}},
        {{1, 1, 1, 1}, {2, 2, 2 ,2, 3, 3, 3, 3}},
        {{0, 0, 0, 0}, {3, 3, 3 ,3, 4, 4, 4, 4}},
        {{0, 0, 0, 0}, {4, 4, 4 ,4, 5, 5, 5, 5}},
        {{0, 0, 1, 1}, {5, 5, 5 ,5, 6, 6, 6, 6}},
        {{0, 0, 0, 1}, {6, 6, 6 ,6, 7, 7, 7, 7}},
        {{1, 0, 0, 0}, {0, 1, 2 ,3, 4, 5, 6, 7}}
};
*/

//This function is fed the current state and an input as well as an array of states
//Based on the input and current state, return the next state
//MealyFSM Struct is in Constants.h
uint8_t GetOutputFromMealy( state_t *Mealy, uint8_t input, uint8_t currentState){
		return(42);

}

//This function is fed the current state, and an input as well as an array of states
//Based on the current state and input, return the next state the Mealy machine should enter
uint8_t getNextState( state_t *Mealy, uint8_t input, uint8_t currentState){
		return(42);

}



//This function is fed a pointer to a scoreStruct
//Go through the array in this struct and sort the elements in increasing order
//In other words the largest number last, smallest number first
//Be sure to account for possible repeats with numbers
//All forms of sorting are allowed
void sortInternalField(score_t *input1){
	  return;
}



//This function is fed an array of Students
//You need to parse through the array of students to find the top scorer
//Top Scorer is defined as the student with the highest test average
//Return the ID number of the student with the highest score
uint32_t topScorer(student_t *inputArray, uint8_t numStudents){
    return(42);
}


