// Exam2Practice
// Runs on LM4F120/TM4C123
// Mohit Tiwari and Matthew Barondeau
// Last Modified: 3/25/2018

#ifndef EXAM2EE319K_GRADER_H
#define EXAM2EE319K_GRADER_H

#include "Constants.h"


#endif //EXAM2EE319K_GRADER_H


uint32_t Grader(void );

void OutputMessage(void);
