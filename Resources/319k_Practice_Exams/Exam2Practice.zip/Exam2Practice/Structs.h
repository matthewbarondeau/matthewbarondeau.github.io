// Exam2Practice
// Runs on LM4F120/TM4C123
// Mohit Tiwari and Matthew Barondeau
// Last Modified: 3/25/2018

#ifndef EXAM2EE319K_STRUCTS_H
#define EXAM2EE319K_STRUCTS_H

#endif //EXAM2EE319K_STRUCTS_H

#include "Constants.h"




uint8_t GetOutputFromMealy( state_t *Mealy, uint8_t input, uint8_t currentState);
uint8_t getNextState( state_t *Mealy, uint8_t input, uint8_t currentState);
void sortInternalField(score_t *input1);
uint32_t topScorer(student_t *inputArray, uint8_t numStudents);
