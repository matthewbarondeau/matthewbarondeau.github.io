
#include "Constants.h"

uint8_t NextState( state_t *Mealy, uint8_t currentState, uint8_t input );
uint32_t AddingPointersInASM(uint16_t *num1, uint16_t *num2, uint16_t *num3);
uint32_t MultiplyingPointersInASM(uint16_t *num1, uint16_t *num2, uint16_t *num3);
void ParsingArrayInASM(char *inputArray, uint8_t sizeOfArray, uint8_t parsingOffset, char *outputArray);
int16_t BreakApartDataASM(uint32_t input1);
int32_t ReturnValueatPointer(uint32_t *pointer);
int32_t FourPointersASM(int32_t *ASMPointer1, int32_t *ASMPointer2, int32_t *ASMPointer3, int32_t *ASMPointer4);
uint32_t rangeUnsortedASM(int32_t *unsortedArray);
uint32_t ASMcallC(student_t *studentArray);

