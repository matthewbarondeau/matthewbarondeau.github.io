
// Exam2Practice
// Runs on LM4F120/TM4C123
// Mohit Tiwari and Matthew Barondeau
// Last Modified: 3/25/2018


#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "UART.h"
#include "PLL.h"
#include "Grader.h"
#include "GraderASM.h"
#include "Constants.h"
#include "Pointers.h"
#include "Structs.h"
int main(void){
	PLL_Init(Bus50MHz);
	UART_Init();
	uint32_t grade=0;
	grade+=Grader();
	grade+=GraderASM();
	UART_OutString("Your Score is: ");
	UART_OutUDec(grade);
	if(grade == 100){
		OutputMessage();
	}
	while(1){
	
	}
	
}
