// Exam2Practice
// Runs on LM4F120/TM4C123
// Mohit Tiwari and Matthew Barondeau
// Last Modified: 3/25/2018

#include "Constants.h"
#include "Pointers.h"
#include "Structs.h"
#include <stdint.h>
#include "UART.h"


uint16_t input1=3;
uint16_t input2=4;
uint16_t input3=5;
uint8_t array1[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, '\0'};
uint8_t array2[] = {1, 9, 8, 7, 6, 5, 4, 3, 2, 1, '\0'};
score_t Input[3] ={
        {3, 7, 5, 4, 3, 1, 9, 12, 3, 0},
        {1, 3, 4, 5, 6, 1, 3, 2, 5, 7},
        {22, 22, 44, 11, 56, 12, 1, 9, 1, 99}
};



int Grade=0;

void pointerMultiplicationGrader(){
	uint16_t PMinput1=3;
	uint16_t PMinput2=4;
	uint16_t PMinput3=5;
    uint32_t result = PointerMultiplication(&PMinput1, &PMinput2, &PMinput3);
    if(result==60){
        PMinput1=0;
        result=PointerMultiplication(&PMinput1, &PMinput2, &PMinput3);
        if(result==0){
            PMinput1=4;
            PMinput3=9000;
            result=PointerMultiplication(&PMinput2, &PMinput3, &PMinput1);
            if(result==144000){
                Grade+=5;
								UART_OutString("All pointerMultiplication cases passed\n");

            }
						else{
							UART_OutString("pointerMultiplication cases failed\n");
						}
        }
				else{
						UART_OutString("pointerMultiplication cases failed\n");
				}
    }
		else{
				UART_OutString("pointerMultiplication cases failed\n");
		}
}

void pointerAdditionGrader(){

    input1=1;
    input2=2;
    input3=3;
    uint32_t result=PointerAddition(&input1, &input2, &input3);
    if(result==6){
        input1=0;
        input2=0;
        input3=0;
        result=PointerAddition(&input1, &input2, &input3);
        if(result==0){
            input3=9000;
            input1=8000;
            result=PointerAddition(&input1, &input2, &input3);
            if(result==17000){
                Grade+=5;
								UART_OutString("All pointerAddition cases passed\n");
            }
						else{
							UART_OutString("pointerAddition cases failed\n");
						}
        }
				else{
						UART_OutString("pointerAddition cases failed\n");
				}
    }
		else{
				UART_OutString("pointerAddition cases failed\n");
		}
}

void sumOfCharArrayGrader(){
		uint8_t CAarray1[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, '\0'};
		uint8_t CAarray2[] = {1, 9, 8, 7, 6, 5, 4, 3, 2, 1, '\0'};
    uint32_t result = SumOfCharArray(&CAarray1[0], &CAarray2[0]);
    if(result==101){
        CAarray1[5]=0;
        CAarray2[7] =0;
        result=SumOfCharArray(&CAarray1[0], &CAarray2[0]);
        if(result==55){
            for(int i=0; i<10; i++){
                CAarray1[i]=0;
                CAarray2[i]=0;
            }
            result=SumOfCharArray(&CAarray1[0], &CAarray2[0]);
            if(result==0){
                Grade+=5;
								UART_OutString("All sumOfCharArray cases passed\n");

            }
						else{
							UART_OutString("sumOfCharArray cases failed\n");
						}
        }
				else{
						UART_OutString("sumOfCharArray cases failed\n");
				}
    }
		else{
				UART_OutString("sumOfCharArray cases failed\n");
		}

}

void sortArrayGrader(){
    uint8_t arrayToSort[] = {1, 9, 30, 6, 2, 20, 3, 12, 10, 11};
    sortArray(&arrayToSort[0]);
    uint8_t sortedArray[] = {1, 2, 3, 6, 9, 10, 11, 12, 20, 30};
    int result=0;
    for(int i=0; i<10; i++){
        if(arrayToSort[i]==sortedArray[i]){
            result++;
        }
    }
    if(result==10){
        Grade+=5;
				UART_OutString("All sortArrayGrader cases passed\n");

    }
		else{
				UART_OutString("sortArray cases failed\n");
		}

}

void lengthOfArrayGrader(){
    uint8_t input1[]={'0', '0', 10, 20, 30, 40, 50, 60 ,70 ,70, '\0'};
    uint8_t input2[]={2, 10, 2, 1, 3, 5, 3, '\0', 1, 4};
    uint8_t input3[]={'\0'};
    uint8_t result = lengthOfArray(&input1[0]);
    if(result==10) {
        result = lengthOfArray(&input2[0]);
        if (result == 7) {
            result = lengthOfArray(&input3[0]);
            if (result == 0) {
                Grade += 5;
								UART_OutString("All lengthOfArray cases passed\n");
            }
						else{
							UART_OutString("lengthOfArray cases failed\n");
						}
        }
    }
}

void lengthOfArrayGrader2(){
    uint8_t input1[10]={10, 20, 30, 40, 50, 60, 70, 80, 90, 0};
    uint8_t input2[12]={2};
    uint8_t input3[94]={0};
    uint8_t result = lengthOfArray2(input1);
    if(result==9) {
        result = lengthOfArray2(input2);
        if (result == 1) {
            result = lengthOfArray2(input3);
            if (result == 0) {
                Grade += 5;
								UART_OutString("All lengthOfArray2 cases passed\n");
            }
						else{
							UART_OutString("lengthOfArray2 cases failed\n");
						}
        }
				else{
						UART_OutString("lengthOfArray2 cases failed\n");
				}
    }
		else{
				UART_OutString("lengthOfArray2 cases failed\n");
		}
}

void alphabetSortGrader(){
    unsigned char AlphabetArray[26] = {'a', 'b', 'd', 'c', 'f', 'e', 'y', 'z', 'g', 'i', 'h', 'k', 'l', 'j', 'o', 'n', 'm', 'q', 'p', 'r', 's', 't', 'u', 'v', 'w', 'x'};
    uint8_t indexOfM = 12;
    char result = alphabetSort(&AlphabetArray[0], indexOfM);
    if(result == 'm'){
        Grade+=5;
				UART_OutString("All alphabetSort cases passed\n");
    }
		else{
				UART_OutString("alphabetSort cases failed\n");
		}
}

void MealyOutputGrader(){
	state_t OutMealy[8] ={
        {{0, 1, 0, 1}, {0, 0, 0 ,0, 1, 1, 1, 1}},
        {{1, 1, 1, 1}, {1, 1, 1 ,1, 2, 2, 2, 2}},
        {{1, 1, 1, 1}, {2, 2, 2 ,2, 3, 3, 3, 3}},
        {{0, 0, 0, 0}, {3, 3, 3 ,3, 4, 4, 4, 4}},
        {{0, 0, 0, 0}, {4, 4, 4 ,4, 5, 5, 5, 5}},
        {{0, 0, 1, 1}, {5, 5, 5 ,5, 6, 6, 6, 6}},
        {{0, 0, 0, 1}, {6, 6, 6 ,6, 7, 7, 7, 7}},
        {{1, 0, 0, 0}, {0, 1, 2 ,3, 4, 5, 6, 7}}
};
    uint8_t result = GetOutputFromMealy(&OutMealy[0], 2, 0);
    if(result==0){
        result=GetOutputFromMealy(&OutMealy[0], 0, 4);
        if(result==0){
            result=GetOutputFromMealy(&OutMealy[0], 0, 7);
            if(result==1){
                Grade+=5;
								UART_OutString("All MealyOutputGrader cases passed\n");
            }
						else{
							UART_OutString("MealyOutput cases failed\n");
						}
        }
				else{
						UART_OutString("MealyOutput cases failed\n");
				}
    }
		else{
				UART_OutString("MealyOutput cases failed\n");
		}
}

void MealyNextStateGrader(){
	state_t Mealy[8] ={
        {{0, 1, 0, 1}, {0, 0, 0 ,0, 1, 1, 1, 1}},
        {{1, 1, 1, 1}, {1, 1, 1 ,1, 2, 2, 2, 2}},
        {{1, 1, 1, 1}, {2, 2, 2 ,2, 3, 3, 3, 3}},
        {{0, 0, 0, 0}, {3, 3, 3 ,3, 4, 4, 4, 4}},
        {{0, 0, 0, 0}, {4, 4, 4 ,4, 5, 5, 5, 5}},
        {{0, 0, 1, 1}, {5, 5, 5 ,5, 6, 6, 6, 6}},
        {{0, 0, 0, 1}, {6, 6, 6 ,6, 7, 7, 7, 7}},
        {{1, 0, 0, 0}, {0, 1, 2 ,3, 4, 5, 6, 7}}
};
    uint8_t result = getNextState( &Mealy[0], 0, 0);
    if(result==0){
        result=getNextState(&Mealy[0], 3, 3);
        if(result==3){
            result=getNextState(&Mealy[0], 7, 7);
            if(result==7){
                Grade+=5;
								UART_OutString("All MealyNextState cases passed\n");
            }
						else{
							UART_OutString("MealyNextState cases failed\n");
						}
        }
				else{
						UART_OutString("MealyNextState cases failed\n");
				}
    }
		else{
				UART_OutString("MealyNextState cases failed\n");
		}
}

void InternalFieldSortGrader(){
		score_t Internal = {3, 7, 5, 4, 3, 1, 9, 12, 3, 0};
		score_t Internal2 = {1, 3, 4, 5, 6, 1, 3, 2, 5, 7};
		score_t Internal3 =  {22, 22, 44, 11, 56, 12, 1, 9, 1, 99};
		score_t Output[3] ={
        {0, 1, 3, 3, 3, 4, 5, 7, 9, 12},
        {1, 1, 2, 3, 3, 4, 5, 5, 6, 7},
        {1, 1, 9, 11, 12, 22, 22, 44, 56, 99}
};
    sortInternalField(&Internal);
    sortInternalField(&Internal2);
    sortInternalField(&Internal3);
    int result=0;
    for(int i=0; i<10; i++){
        if(Internal.scores[i]==Output[0].scores[i] &&Internal2.scores[i]==Output[1].scores[i] && Internal3.scores[i]==Output[2].scores[i]){
            result++;
        }
    }
    if(result==10){
        Grade+=5;
				UART_OutString("All InternalFieldSort cases passed\n");
    }
		else{
				UART_OutString("InternalFieldSort cases failed\n");
		}
}

void OutputMessage(){
			UART_OutString("\nMatthew wishes you luck on your exam!\n");
}

void topScorerGrader(){
	
	student_t Students[5] ={
        {123, 94, 12},
        {99734, 88, 100},
        {123131, 40, 75},
        {0, 0, 0},
        {100, 100, 100}
};
    uint32_t result = topScorer( &Students[0], 5);
    if(result == 100){
        Grade+=5;
				UART_OutString("All topScorer cases passed\n");
    }
		else{
				UART_OutString("topScorer cases failed\n");
		}
}


uint32_t  Grader(){
    pointerMultiplicationGrader();
    pointerAdditionGrader();
    sumOfCharArrayGrader();
    sortArrayGrader();
    lengthOfArrayGrader();
    lengthOfArrayGrader2();
    alphabetSortGrader();
    MealyOutputGrader();
    MealyNextStateGrader();
    InternalFieldSortGrader();
    topScorerGrader();
    return Grade;
}





