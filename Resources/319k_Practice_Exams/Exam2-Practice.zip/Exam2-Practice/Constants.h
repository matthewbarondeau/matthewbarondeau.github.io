// Exam2Practice
// Runs on LM4F120/TM4C123
// Mohit Tiwari and Matthew Barondeau
// Last Modified: 3/25/2018

#ifndef EXAM2EE319K_CONSTANTS_H
#define EXAM2EE319K_CONSTANTS_H

#include <stdint.h>

struct state {
    uint8_t output[4];
    uint8_t nextState[8];
};

typedef struct state state_t;

struct scoreStruct {
    uint8_t scores[10];
};

typedef  struct scoreStruct score_t;

struct Student {
    uint32_t studentIDNumber;
    uint16_t scoreExam1;
    uint16_t scoreExam2;
};

typedef struct Student student_t;



#endif //EXAM2EE319K_CONSTANTS_H

