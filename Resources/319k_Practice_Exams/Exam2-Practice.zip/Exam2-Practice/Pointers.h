// Exam2Practice
// Runs on LM4F120/TM4C123
// Mohit Tiwari and Matthew Barondeau
// Last Modified: 3/25/2018


#include "Constants.h"


#ifndef EXAM2EE319K_POINTERS_H
#define EXAM2EE319K_POINTERS_H

#endif //EXAM2EE319K_POINTERS_H


uint32_t PointerMultiplication(uint16_t *num1, uint16_t *num2, uint16_t *num3);
uint32_t PointerAddition(uint16_t *num1, uint16_t *num2, uint16_t *num3);
uint32_t SumOfCharArray(uint8_t *array1, uint8_t *array2);

void sortArray(uint8_t *array);                     //need to fix this
uint8_t lengthOfArray(uint8_t *array);
uint8_t lengthOfArray2(uint8_t array[]);
char alphabetSort(unsigned char AlphabetArray[], uint8_t indexToReturn);

