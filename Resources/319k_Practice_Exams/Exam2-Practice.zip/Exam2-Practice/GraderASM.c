// Exam2Practice
// Runs on LM4F120/TM4C123
// Mohit Tiwari and Matthew Barondeau
// Last Modified: 3/25/2018

#include "Constants.h"
#include <stdint.h>
#include "UART.h"



uint8_t NextState( state_t *Mealy, uint8_t currentState, uint8_t input );
uint32_t AddingPointersInASM(uint16_t *num1, uint16_t *num2, uint16_t *num3);
uint32_t MultiplyingPointersInASM(uint16_t *num1, uint16_t *num2, uint16_t *num3);
void ParsingArrayInASM(uint8_t *inputArray, uint8_t sizeOfArray, uint8_t parsingOffset, uint8_t *outputArray);
uint32_t BreakApartDataASM(uint32_t input1);
int32_t ReturnValueatPointer(uint32_t *pointer);
int32_t FourPointersASM(int32_t *ASMPointer1, int32_t *ASMPointer2, int32_t *ASMPointer3, int32_t *ASMPointer4);
uint32_t rangeUnsortedASM(uint8_t *unsortedArray);
uint32_t ASMcallC(score_t *studentArray);


uint32_t grade;

void NextStateGrader(){
	state_t AMealy[8] ={
        {{0, 1, 0, 1}, {0, 0, 0 ,0, 1, 1, 1, 1}},
        {{1, 1, 1, 1}, {1, 1, 1 ,1, 2, 2, 2, 2}},
        {{1, 1, 1, 1}, {2, 2, 2 ,2, 3, 3, 3, 3}},
        {{0, 0, 0, 0}, {3, 3, 3 ,3, 4, 4, 4, 4}},
        {{0, 0, 0, 0}, {4, 4, 4 ,4, 5, 5, 5, 5}},
        {{0, 0, 1, 1}, {5, 5, 5 ,5, 6, 6, 6, 6}},
        {{0, 0, 0, 1}, {6, 6, 6 ,6, 7, 7, 7, 7}},
        {{1, 0, 0, 0}, {0, 1, 2 ,3, 4, 5, 6, 7}}
};
		uint8_t result = NextState(&AMealy[0], 3, 3);
		if(result == 3){
				result = NextState(&AMealy[0], 7, 0);
				if(result == 0){
						grade+=5;
						UART_OutString("All NextStateASM cases passed\n");
				}
				else{
						UART_OutString("NextStateASM cases failed\n");
				}
		}
		else{
				UART_OutString("NextStateASM cases failed\n");
		}
}

void AddingPointersInASMGrader(){
		uint16_t input1=5;
		uint16_t input2=7;
		uint16_t input3=12;
		uint32_t result = AddingPointersInASM(&input1, &input2, &input3);
		if(result==24){
				input1=0;
				result = AddingPointersInASM(&input1, &input2, &input3);
				if(result==19){
						grade+=5;
						UART_OutString("All AddingPointersInASM cases passed\n");
				}
				else{
							UART_OutString("AddingPointersInASM cases failed\n");
				}
		}
		else{
				UART_OutString("AddingPointersInASM cases failed\n");
		}
}

void MultiplyingPointersInASMGrader(){
		uint16_t input1=3;
		uint16_t input2=7;
		uint16_t input3=9;
		uint32_t result = MultiplyingPointersInASM(&input1, &input2, &input3);
		if(result==189){
				input1=2;
				result = MultiplyingPointersInASM(&input1, &input2, &input3);
				if(result==126){
						grade+=5;
						UART_OutString("All MultiplyingPointersInASM cases passed\n");
				}
				else{
						UART_OutString("MultiplyingPointersInASM cases failed\n");
				}
		}
		else{
				UART_OutString("MultiplyingPointersInASM cases failed\n");
		}
}

void ParsingArrayInASMGrader(){
		uint8_t inputArray[] = { 'a', 'd', 'q', 'e', 'r', 'i', 'p', 'n', 'a', 'b', 'c', 'e', 0};
		uint8_t outputArray[] = {'a', 'e', 'p', 'b'};
		uint8_t resultArray[] ={0, 0, 0, 0, 0, 0, 0, 0, 0 ,0 ,0 ,0};
		ParsingArrayInASM(&inputArray[0], 12, 3, &resultArray[0]);
		int i=0; 
		while(resultArray[i]!='\0'){
				i++;
		}
		if(i>=4){
				int j;
				for(j=0; j<i; j++){
						if(outputArray[j]!=resultArray[j]){
								break;
						}
				}
				if(j==i){
						grade+=5;
						UART_OutString("All ParsingArrayInASM cases passed\n");
				}
				else{
						UART_OutString("ParsingArrayInASM cases failed\n");
				}
		}
		else{
				UART_OutString("ParsingArrayInASM cases failed\n");
		}
}

void BreakApartDataASMGrader(){
		uint32_t input1 = 0x0F010A04;
		uint32_t result = BreakApartDataASM(input1);
		if(result == 600){
				input1=0xFFFFFFFF;
				result = BreakApartDataASM(input1);
				if(result == 4228250625){
						grade+=5;
						UART_OutString("All BreakApartDataASM cases passed\n");
				}
				else{
						UART_OutString("BreakApartDataASM cases failed\n");
				}
		}
		else{
				UART_OutString("BreakApartDataASM cases failed\n");
		}
}

void ReturnValuesatPointerGrader(){
		uint32_t input1 = 55;
		uint32_t input2 = 4000000000;
		uint32_t input3 = 0;
		uint32_t result = ReturnValueatPointer(&input1);
		if(result==55){
				result = ReturnValueatPointer(&input2);
				if(result ==4000000000){
						result = ReturnValueatPointer(&input3);
						if(result==0){
								grade+=5;
								UART_OutString("All ReturnValuesatPointer cases passed\n");
						}
						else{
								UART_OutString("ReturnValuesatPointer cases failed\n");
						}
				}
				else{
						UART_OutString("ReturnValuesatPointer cases failed\n");
				}
		}
		else{
				UART_OutString("ReturnValuesatPointer cases failed\n");
		}
}

void FourPointersASMGrader(){
		int32_t input1=1;
		int32_t input2=2;
		int32_t input3=3;
		int32_t input4=4;
		int32_t result = FourPointersASM(&input1, &input2, &input3, &input4);
		if(result==24){
				input4=90;
				result = FourPointersASM(&input1,&input2, &input3, &input4);
				if(result==540){
						grade+=5;
						UART_OutString("All FourPointersASM cases passed\n");
				}
				else{
						UART_OutString("FourPointersASM cases failed\n");
				}
		}
		else{
			UART_OutString("FourPointersASM cases failed\n");
		}
}

void rangeUnsortedASMGrader(){
		uint8_t inputArray[]={1, 3, 4, 5, 7, 1, 5, 6, 1, 90, 0};
		uint32_t range = rangeUnsortedASM(&inputArray[0]);
		if(range==89){
				inputArray[9]=91;
				range = rangeUnsortedASM(&inputArray[0]);
				if(range==90){
						grade+=5;
						UART_OutString("All rangeUnsortedASM cases passed\n");
				}
				else{
						UART_OutString("rangeUnsortedASM cases failed\n");
				}
		}
		else{
				UART_OutString("rangeUnsortedASM cases failed\n");
		}
		
}

void ASMcallCGrader(){
		score_t Exam1Scores = {1, 40, 100, 90, 48, 86, 75, 12, 9, 90};
		uint32_t range = ASMcallC(&Exam1Scores);
		if(range==99){
				grade+=5;
				UART_OutString("All ASMcallC cases passed\n");
		}
		else{
				UART_OutString("ASMcallC cases failed\n");
		}
}

uint32_t GraderASM(){
		grade = 0;
		NextStateGrader();
		AddingPointersInASMGrader();
		MultiplyingPointersInASMGrader();
		ParsingArrayInASMGrader();
		BreakApartDataASMGrader();
		ReturnValuesatPointerGrader();
		FourPointersASMGrader();
		rangeUnsortedASMGrader();
		ASMcallCGrader();		
		return(grade);
}


