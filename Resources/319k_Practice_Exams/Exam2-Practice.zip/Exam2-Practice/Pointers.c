// Exam2Practice
// Runs on LM4F120/TM4C123
// Mohit Tiwari and Matthew Barondeau
// Last Modified: 3/25/2018

#include <stdint.h>
#include "Pointers.h"

//PointerSection

//Multiply num1, num2, and num3 together
//Return the result
uint32_t PointerMultiplication(uint16_t *num1, uint16_t *num2, uint16_t *num3){
	return(42);

}


//Add num1, num2, and num3 together
//Return the result of the addition
uint32_t PointerAddition(uint16_t *num1, uint16_t *num2, uint16_t *num3){
		return(42);

}



//Given two pointers to character arrays
//Add all elements of the two arrays together
//Might be beneficial to write length of Array first
uint32_t SumOfCharArray(uint8_t *array1, uint8_t *array2){
		return(42);
}


//Sort an Array of characters given a pointer to the array
//Array is null terminated
//Length of Array may be beneficial to write first
void sortArray(uint8_t *array){
		return;
}



//Find the length of a character array using a pointer
//array is null terminated
uint8_t lengthOfArray(uint8_t *array){
		return(42);
}


//Find the length of a null terminated character array
uint8_t lengthOfArray2(uint8_t array[]){
		return(42);
}


//Sort an array of characters
//Return the element at indexToReturn
char alphabetSort(uint8_t *AlphabetArray, uint8_t indexToReturn){
		return(42);
}

